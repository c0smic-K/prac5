CREATE TABLE User(
    user_id INT AUTO_INCREMENT,
    firstname VARCHAR(50) NOT NULL,
    surname VARCHAR(50) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE,
    grade VARCHAR(255) NULL; -- (grade 8-9) get TVET Collages else; option of Versity & TVET.
    password VARCHAR(50) NOT NULL,
    subjects JSON NULL, -- List of the Users subjects 
    marks JSON NULL, -- List of the users Marks for said subjects
	PRIMARY KEY(user_id)
);


CREATE TABLE CourseRequirements (
    requirement_id INT AUTO_INCREMENT,
    course_name VARCHAR(255),
    subject_combinations JSON, -- list of possible subject combinations
    min_marks JSON, -- minimum marks for each subject in a combination
    institution_id INT,
    PRIMARY KEY(requirement_id),
    foreign key (institution_id)
    references Institution(institution_id)   
);

 -- Example Data
INSERT INTO CourseRequirements (course_name, subject_combinations, min_marks)
VALUES
    ('Engineering', '[["Mathematics", "Physics"], ["Chemistry", "Biology"]]', '[{"Mathematics": 60, "Physics": 55}, {"Chemistry": 65, "Biology": 60}]: 60}]'),

    ('Education', '[["English", "Mathematics"], ["English", "Mathematics Literacy"]]', '[{"English": 50, "Mathematics": 40}, {"English": 50, "Mathematics Literacy": 50}]'),
    ('Pharmacy', '[["Mathematics", "Physics"], ["Mathematics", "Life Science"]]', '[{"Mathematics": 60, "Physics": 60}, {"Mathematics": 60, "Life Science": 60}]'),
    ('Pharmacy (Provisional Offer)', '[["Mathematics", "Physics"], ["Mathematics", "Life Science"]]', '[{"Mathematics": 70, "Physics": 70}, {"Mathematics": 70, "Life Science": 70}]');
    ('Humanities', '[["English Home Language"], ["English First Language"]]', '[{"English Home Language": 60}, {"English First Language": 65}]');
    ('Bachelor of Business Science', '[["English", "Mathematics"]]', '[{"English": 50, "Mathematics": 70}]');
    ('Bcom Programmes', '[["English", "Mathematics"]]', '[{"English": 50, "Mathematics": 50}]');
    ('Law', '[["English Home Language", "Mathematics"], ["English Home Language", "Mathematics Literacy"], ["English First Language", "Mathematics"], ["English First Language", "Mathematics Literacy"]]', '[{"English Home Language": 50, "Mathematics": 50}, {"English Home Language": 50, "Mathematics Literacy": 60}, {"English First Language": 70, "Mathematics": 50}, {"English First Language": 70, "Mathematics Literacy": 60}]');

    ('Computer Science', '[["Mathematics", "Computer Science"], ["Physics", "Computer Science"]]', '[{"Mathematics": 65, "Computer Science": 60}, {"P}, {"Physics": 60, "Computer Science": 65}]');


CREATE TABLE Institution(
    institution_id INT,
    institution_name CHAR(255) NOT NULL,
    type CHAR(255) NOT NULL, -- Either Varsity or TVET
    applicationOpen_Date DATE NULL, 
    applicationClosing_Date DATE NULL,
    description CHAR(255) NOT NULL,
    like INT NULL,
    PRIMARY KEY(institution_id)
);

INSERT INTO Institution(institution_id, institution_name, type, applicationOpen_Date, applicationClosing_Date, description)
VALUES 
    ('1', 'Rhodes University', 'Varsity', '19 April 2024', '30 September 2024', 'Located at Makanda, Grahamnstown. It is home to a diverse range of undergraduate and postgraduate programs across various faculties. Known for its strong focus on research and innovation. Attracting students from around the world who seek a quality education and a supportive learning environment.'),
    ('2', 'WSU', 'Varsity', '01 June 2024', '31 October 2024', 'This institution has a number of campuses scattered around the Easter Cape, located in Mthatha, East London, and Butterworth. It offers a wide range of undergraduate and postgraduate programs across various disciplines. WSU is committed to providing quality education and is known for its focus on community engagement and social responsibility.'),
    ('3', 'WITS', 'Varsity', '01 March 2024', '30 September 2024', 'The University of the Witwatersrand is one of the leading South African universities located in Johannesburg. It is known for its strong research focus and its contributions to various fields. Wits offers a wide range of undergraduate and postgraduate programs across its faculties. The university is home to a diverse student body and has a reputation for academic excellence and innovation.'),
    ('4', 'University Of Western Cape', 'Varsity', '02 April 2024', '30 September 2024', 'University of the Western Cape is located in Bellville, Cape Town. And it is known for its commitment to social justice and transformation. UWC offers a diverse range of undergraduate and postgraduate programs across its faculties. The university is home to a vibrant student community and is known for its strong research focus.'),
    ('5', 'University of Johannesburg', 'Varsity', '01 April 2024', '01 October 2024', 'University of Johannesburg has campuses located in Johannesburg and Soweto, South Africa. It is known for its strong focus on innovation and entrepreneurship. UJ offers a wide range of undergraduate and postgraduate programs across its faculties. The university is home to a diverse student body and is known for its research excellence.'),
    ('6', '', 'TVET', '', '', ''),
    ('7', '', 'TVET', '', '', ''),
    ('8', '', 'TVET', '', '', '');


CREATE TABLE CoursesMatched(
    courseMatched_id INT AUTO_INCREMENT,
    user_id INT,
    requirement_id INT NULL,
    PRIMARY KEY(courseMatched_id),
    foreign key (user_id)
    references User(user_id),
    foreign key (requirement_id)
    references CourseRequirements(requirement_id )
);

CREATE TABLE ratings(
    rating_id INT AUTO_INCREMENT, 
    user_id INT,
    rating INT,
    comment CHAR(255),
    date DATE  DEFAULT CURDATE(),
    PRIMARY KEY(rating_id),
    foreign key (user_id)
    references User(user_id)
);

 -- JSON object
JSON
[
    {"Mathematics": 60, "Physics": 55},
    {"Chemistry": 65, "Biology": 60}
]

CREATE TABLE Like (
    like_id INT AUTO_INCREMENT, 
    user_id INT,
    institution_id INT,
    PRIMARY KEY(like_id),
    foreign key (institution_id)
    references Institution(institution_id),
    foreign key (user_id)
    references User(user_id)
);