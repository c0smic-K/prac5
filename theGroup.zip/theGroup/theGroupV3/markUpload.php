<?php
// Security
require_once('secure.php');
// Gets DB credentials
require_once('config.php');

// Assuming you're receiving the subject and mark as separate POST parameters
$subject = $_POST['subjects'];
$mark = $_POST['mark'];

// Validate the input (optional)
if (empty($subject) || empty($mark)) {
    die("Please enter both subject and mark.");
}

// Create a JSON object
$subjectData = [
    $subject
];

$markData = [
    $mark
];

// Establish a Connection
$conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

if ($conn->connect_error) {
    die("<p>Connection could Not be established</p>");
}

// Prepare the SQL statement with placeholders
$sql = marksExists($conn);

$subjectData = json_encode($subjectData);
$markData = json_encode($markData);

// Bind the parameters
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $subjectData, $markData, $_SESSION['user']);

if ($stmt->execute()) {
    //Redirects the user to main page
    header("Location: searchUpdtd.php");
} else {
    die("<p>Query error: " . $stmt->error . "</p>");
}

// Close the statement and connection
$stmt->close();
$conn->close();

function marksExists($conn1){

    $stmnt = "SELECT subjects FROM User WHERE user_id = '{$_SESSION['user']}'";
    $ans = $conn1 -> query($stmnt);

    if ($ans === false){
        die("<p>Stmnt error</p>");

    } 
    
    $row = $ans -> fetch_assoc();
    
    if (!empty($row['subjects'])) {
        return"UPDATE User
                SET subjects = JSON_ARRAY_APPEND(subjects, '$', ?), 
                marks = JSON_ARRAY_APPEND(marks, '$', ?)
                WHERE user_id = ?";
    } elseif (empty($row['subjects'])) {
        return "UPDATE User
                SET subjects = ?, 
                marks = ?
                WHERE user_id = ?";
    }
}
?>