<?php
    //Security
    require_once('secure.php');

    //Get DB credentials
    require_once('config.php');

    //Establish connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    if ($conn -> connect_error) {
        die("<p>Connection Error</p>");
    }

    $sql = "SELECT Coursesmatched.requirement_id, course_name, Institution.institution_name, Institution.applicationOpen_Date, Institution.applicationClosing_Date,  Institution.description
            FROM Coursesmatched
            join courserequirements
            ON courserequirements.requirement_id = Coursesmatched.requirement_id
            join Institution
            ON Institution.institution_id = courserequirements.institution_id
            WHERE user_id = '{$_SESSION['user']}'";
    
    $result = $conn -> query($sql);

    if ($result === false) {
        die("<p>Query Error</p>");
    }

    while ($row = $result -> fetch_assoc()) {
        echo "<ul>";
        echo "<li><h2>{$row['course_name']}</h2></li>";
        echo "<li>{$row['institution_name']}</li>";
        echo "<li>Appications Open: {$row['applicationOpen_Date']}</li>";
        echo "<li>Appications closes: {$row['applicationClosing_Date']}</li>";
        echo "<li>{$row['description']}</li>";
        echo "</ul>";
    }

    //Close connection
    $conn -> close();
?>

