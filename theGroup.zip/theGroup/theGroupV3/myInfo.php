<?php //Security
    require_once('secure.php');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>College Compass</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="search.css">
        <link rel="stylesheet" href="about.css">
        
    </head>
    <body>
        <header style="font-family: 'Courier New', Courier, monospace;">
            <table width="100%">
            <tr>
                <td width="20%" style="text-align: center;">
                <img src="WhatsApp Image 2024-09-11 at 21.31.03_9560cae1.jpg" alt="College Compass logo">
                </td>
                <td style="color: brown; text-align: center;">
                <h1>CollegeCompass</h1>
                <h2>Navigating Your Future, Made Easier.</h2>
                </td>
            </tr>
            </table>
        </header>

        <nav style="font: 1em sans-serif;">
            <ul class="tab">
                <li class="item"><a class="nav" href="homeUpdtd.php">Home</a></li>
                <li class="item"><a class="nav" href="searchUpdtd.php">Search</a></li>
                <li class="item"><a class="nav" href="myInfo.php">myInfo</a></li>
                <li class="item"><a class="nav" href="about.php">About Us</a></li>
                <li><a class="logout" href="logout.php">Logout</a></li>
            </ul>
        </nav>
<div style="margin-left: 5%;">
<?php
    //gets DB credentials
    require_once('config.php');

    //Establishes a Connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    if ($conn -> connect_error) {
        die("<p>Connection could Not be established</p>");
    } //Error Handling

    $sql = "SELECT username, email, grade, password, subjects, marks
            FROM User
            WHERE user_id = '{$_SESSION['user']}'";

    $result = $conn -> query($sql);

    if ($result === false) {
        die("<p>Query error</p>");
    } //Error handling

    while ($row = $result -> fetch_assoc()) {
        echo "<form class= \"MyInfo\" action= \"editDetails.php\" method= \"post\">";
        echo "<br><label for=\"username\">Username</label>";
        echo "<br><input type= \"text\" name= \"username\" value= \"{$row['username']}\"><br>";
        echo "<br><label for=\"mail\">E-Mail</label>";
        echo "<br><input type= \"text\" name= \"mail\" value= \"{$row['email']}\"><br>";

        if ($row['grade'] == 8) {
            echo "<br><label for=\"grade\">Grade</label>";
            echo "<br><select name= \"grade\" id= \"grade\" placeholder= \"Grade 8 - 11\">
                      <option value= \"12\">Grade 12</option>
                      <option value= \"12\">Matriculated</option>
                </select><br>";
        } else if ($row['grade'] == 12) {
            echo "<br><select name= \"grade\" id= \"grade\" placeholder= \"Grade 12\">
                    <option value= \"12\">Matriculated</option>
                </select><br>";
        } else {
            echo "<br><label for=\"grade\">Grade</label>";
            echo "<br><input type= \"text\" name= \"grade\" value= \"{$row['grade']}\"><br>";
        }

        echo "<br><label for=\"newPassword\">Password</label>";
        echo "<br><input type= \"text\" name= \"newPassword\"><br>";

        echo "<br><label for=\"confirmPassword\">New Password</label>";
        echo "<br><input type= \"text\" name= \"confirmPassword\"><br>";
        echo "<br><input type= \"submit\" value= \"Edit\" id= \"editBtn\">";
    }
    if (!empty($row['subjects']) && !empty($row['marks'])) {
        $sub = json_decode($row['subjects']);
        $mark = json_decode($row['marks']);
        echo "<p>{$sub}</p>";
        echo "<p>{$mark}</p>";
    }

    //Closes the Connection
    $conn -> close();
?>
</div>
        <footer>
            <hr>
            <p>&copy; 2024 College Compass. All rights reserved.</p>
            <p>Author: theGroup &nbsp; 02-Sept-2024</p>
            <p><a href="mailto:thegroup@gmail.com">thegroup@gmail.com</a></p>
        </footer>
    </body>
</html>
