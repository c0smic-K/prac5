<?php
    //Security
    require_once('secure.php');
    //DB Credentials
    require_once('config.php');

    //Establish the connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    if ($conn -> connect_error) {
        die("<p>Connection Error</p>");
    } //Error Handling

    $sql = "SELECT firstname FROM User WHERE user_id = '{$_SESSION['user']}'";

    $result = $conn -> query($sql);

    if($result === false){
        die("<p>Query Error</p>");
    }

    while($row = $result->fetch_assoc()){
        echo "<h1>Welcome {$row['firstname']}!</h1>";
    }

    //Close connection
    $conn -> close();
?>