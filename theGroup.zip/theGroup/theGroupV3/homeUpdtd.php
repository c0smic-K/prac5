<?php 
    //Security
    require_once('secure.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="a6aa2143-ee38-4807-95b8-9bc70833fc20.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="institutionLike.js"></script>
    <title>Home</title>
</head>
<body>
    
    <header style="background-color: lightblue; font-family: 'Courier New', Courier, monospace;">

        <table width = "100%">
            <tr>
                <td width = "20%">
                    <img src="WhatsApp Image 2024-09-11 at 21.31.03_9560cae1.jpg" alt="logo" width="100%" height="100%">
                </td>
                <td style="color: brown; text-align: center;">
                    <h1>CollegeCompass</h1>
                    <h2>Navigating Your Future,  Made Easier.</h2>
                </td>
            </tr>
        </table>

    </header>

    <nav style="font: 1em sans-serif;">

        <ul class="tab">
            <li class="item"><a class="nav" href="homeUpdtd.php">Home</a></li>
            <li  class="item"><a class="nav" href="searchUpdtd.php">Search</a></li>
            <li class="item"><a class="nav" href="myInfo.php">myInfo</a></li>
            <li class="item"><a class="nav" href="about.php">About Us</a></li>
            <li><a class="logout" href="logout.php">Logout</a></li>
        </ul>

    </nav>

    <section class="welcome" style="font: 1em sans-serif;"><br>
    
        <?php require('getUserFirstname.php'); ?>

        <article>
            <p>TheGroup is a collective of third-year Computer Science students at Rhodes University who are dedicated to assisting prospective undergraduates in choosing the right academic path.</p>
            <p>This site is designed to help all potential higher education students discover suitable institutions, whether they're universities or TVET colleges. By inputting their most recent academic results, 
                they can generate a personalized list of institutions and courses that match their qualifications. This streamlines the application process, making it less stressful.
            </p>
        </article>

    </section>
    <section class="institutions" style="font: 1em sans-serif;">

        <br><h2>Application Info</h2>

            <?php 
                //DB Credentials
                require_once('config.php');

                $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

                if ($conn -> connect_error) {
                    die("<p>Connection Error</p>");
                } //Error Handling

                if ($_SESSION['grade'] == '8') {    //Students in grades 8 to 11 are able to apply to strictly TVET colleges
                    $sql = "SELECT institution_id, institution_name, applicationOpen_Date, applicationClosing_Date, description
                            FROM Institution
                            WHERE type = 'TVET'";
                } else {    //While students in grade 12 or have matriculated have the option of Varisty or Collage 
                    $sql = "SELECT institution_id, institution_name, applicationOpen_Date, applicationClosing_Date, description
                            FROM Institution";
                }

                $result = $conn -> query($sql);

                if ($result === false) {
                    die("<p>Query Error</p>");
                }

                echo "<table class= \"application\" width = \"100%\">
                        <tr style= \"background-color: orange;\">
                            <td>Institution</td>
                            <td>Opening Date</td>
                            <td>Closing Date</td>
                            <td width = \"60%\">Description</td>
                        </tr>";

                while($row = $result -> fetch_assoc()){
                    echo "<tr>";
                    echo "<td>{$row['institution_name']}</td>";
                    echo "<td>{$row['applicationOpen_Date']}</td>";
                    echo "<td>{$row['applicationClosing_Date']}</td>";
                    echo "<td>{$row['description']}</td>";
                    echo "<td><span class= \"hidden-content\"><a href=\"like.php?id={$row['institution_id']}\"><input type = \"button\" value = \"like\" class=\"thumbs-up-button\"></a></span></td>";
                    echo "</tr>";
                }    
                echo "</table>";

                //Close the connection
                $conn -> close();  
            ?>

        <br><a href="searchUpdtd.php"><button class="button" style="vertical-align:middle"><span>Search</span></button></a>

    </section>

    <section class="funding" style="font: 1em sans-serif;">

        <br><h2>Funding Info</h2>

        <article>
            <p>
                Do you require funding?
            </p>
            <p>There are numerous organizations that offer bursaries, scholarships, or loans to assist students financially. Popular examples include NSFAS and FUNZA, which have helped countless graduates. 
                Each organization has specific requirements, so it's essential to carefully research your options to find the best fit. 
                Additionally, be mindful of application deadlines and submit your applications well in advance.
                <br><br>Applications for the careerwise bursary are accepted anytime. And it has been confirmed that 2025 National Student Financial Aid Scheme (NSFAS) applications will open in September 2024. 
                With the AWS bursary (closing: 30 November 2024) And New applications for the Funza bursary close on 16 January 2025 and Re-applications for Existing/Returning Bursars close on 30 November 2024.</p>
            <ul class="bursaries">
                <li><a class="link" href="https://www.nsfas.org.za/content/how-to-apply.html">NSFAS</a></li>
                <li><a class="link" href="https://www.eservices.gov.za/tonkana/category/education.xhtml">FUNZA</a></li>
                <li><a class="link" href="https://careerwise.co.za/ats/profile-registration/">Careerwise Bursary</a></li>
                <li><a class="link" href="https://studytrust.devman.co.za/devman/bursary/application/amazon-web/"> AWS SKILLS DEVELOPMENT BURSARY</a></li>
                <li><a class="link" href="https://www.zabursaries.co.za/bursaries-closing-in-november-2024/">More...</a></li>
            </ul>
        </article>

    </section>

    <section class="review" style="font: 1em sans-serif;">

        <br><h2>Review</h2>

        <form action="review.php">
            <fieldset>
             <legend>Review:</legend>
             <div class="rating">
                <input type="radio" id="star5" name="rating" value="1">
                <label for="star5">&#9733;</label>
                <input type="radio" id="star4" name="rating" value="2">
                <label for="star4">&#9733;</label>
                <input type="radio" id="star3" name="rating" value="3">
                <label for="star3">&#9733;</label>
                <input type="radio" id="star2" name="rating" value="4">
                <label for="star2">&#9733;</label>
                <input type="radio" id="star1" name="rating" value="5">
                <label for="star1">&#9733;</label>
            </div>
             <br><textarea name="comment" id="comment" placeholder="Write Your Review..." rows="4" cols="50"></textarea><br>
             <input class="comment" name="submit" type="submit" value="Submit" onclick="commentValidation()">
             <p id="output"></p>
             <script src="rating.js"></script>
            </fieldset>

        </form>
    </section><br>

    <?php require('getRatings.php'); ?>

    <footer style="background-color: lightblue; font-family: 'Courier New', Courier, monospace;">
        <hr>
        <p> &copy; copyright reserved</p> 
        <p>Author: theGroup &nbsp; 02-Sept-2024</p>
        <p><a href="mailto:thegroup@gmail.com">thegroup@gmail.com</a></p><br>
    </footer>

</body>
</html>