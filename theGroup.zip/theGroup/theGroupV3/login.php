<head>
    <style>
        .error{
            color: red;
        }
    </style>
</head>

<?php
    //Start the Student Session
    session_start();

    //Gets Credentials
    require_once('config.php');

    //Establish the connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    //Gets the values from the form
    $username = $conn -> real_escape_string($_REQUEST['username']);
    $password = $conn -> real_escape_string($_REQUEST['password']);

    if ($conn -> connect_error) {
        die("<p class = \"error\">Could not establish a connection</p>");
    }   // Error Handling

    $sql = "SELECT * FROM User
            WHERE username = ? 
            AND password = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, sha1($password));
    $stmt->execute();
    $result = $stmt->get_result();

    if($result === false){
        die("<p class= \"\">Query Error</p>");
    }

    //Checks if the user exists
    if($result -> num_rows == 1){
        $_SESSION['access'] = "yes";
        while ($row = $result->fetch_assoc()) {
            $_SESSION['user'] = $row['user_id'];
            $_SESSION['grade'] = $row['grade'];
    
            //Redirects the user to main page
            header("Location: homeUpdtd.php");
        }
    }else{
        //redirect back to login, if the user does not exist
        header("Location: login2.html");
        
    }
    //Closes the connection
    $conn -> close();