function markValidation(){

    let mark = document.forms["MyMarkform"]["mark"].value;
    mark = parseInt(mark);

    let msg;

    if (mark < 0 || mark > 100) {
        window.alert("Invalid Marks entered (1 - 100)");
    }
}