<?php

    if(isset($_REQUEST['submit'])){
    //Security
    require_once('secure.php');

    //gets DB credentials
    require_once('config.php');

    $rating = $_REQUEST['rating'];
    $comment = $_REQUEST['comment'];
    
    //Establishes a Connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    if ($conn -> connect_error) {
        die("<p>Connection could Not be established</p>");
    } //Error Handling

    $sql = "INSERT INTO ratings(user_id, rating, comment)
            VALUE ('{$_SESSION['user']}', $rating, '$comment')";

    $result = $conn -> query($sql);
    
    if ($result === false) {
        die("<p>Query error</p>");
    } //Error handling

    //Redirects the user to main page
    header("Location: homeUpdtd.php");

    //Closes the Connection
    $conn -> close();}
?>