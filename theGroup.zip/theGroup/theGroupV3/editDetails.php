<?php 
    //Security
    require_once('secure.php');

    //Get DB credentials
    require_once('config.php');

    //Establish a connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    $name = $_REQUEST['username'];
    $mail = $_REQUEST['mail'];
    $grade = $_REQUEST['grade'];
    $newPassword = $_REQUEST['confirmPassword'];

    if ($conn -> connect_error) {
        die("<p>Connection Error</p>");
    }

    if (empty($newPassword)){
        $sql = "UPDATE User
            SET username = '$name', email = '$mail', grade = $grade
            WHERE user_id = '{$_SESSION['user']}'";
    } else {
        $sql = "UPDATE User
            SET username = '$name', email = '$mail', grade = $grade, password = '$newPassword' 
            WHERE user_id = '{$_SESSION['user']}'";

    }

    $result = $conn -> query($sql);

    if($result === false){
        die("<p>Query Error</p>");
    }

    //perform 
    echo "<script>alert('Successfully updated'); </script>";

    //Redirects the user to main page
    header("Location: myInfo.php");

    //Close connection
    $conn -> close();
?>