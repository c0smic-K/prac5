<?php
    if (isset($_REQUEST['find'])) {
    //Security
    require_once('secure.php');

    //gets DB credentials
    require_once('config.php');

    //Establishes a Connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    if ($conn -> connect_error) {
        die("<p>Connection could Not be established</p>");
    } //Error Handling

    // Query to Match Users and Institutions
    $sql = "SELECT Institution.institution_name, Institution.description, Institution.courses, Institution.applicationOpen_Date, Institution.applicationClosing_Date
            FROM User 
            JOIN CoursesMatched
            ON Users.user_id = CoursesMatched.user_id
            JOIN CourseRequirements 
            ON CoursesMatched.requirement_id = CourseRequirements.requirement_id
            JOIN Institution
            ON CourseRequirements.course_name = Institutions.courses -- In the DB : Institutions.requirement_id (might need to change one or the other)
            WHERE
                -- Check if user's subjects and marks meet the requirements
                -- Example using JSON functions (specific syntax might vary based on database):
                JSON_CONTAINS(CourseRequirements.subject_combinations, User.subjects)
            AND 
                JSON_EXTRACT(User.marks, '$[0]') >= JSON_EXTRACT(CourseRequirements.min_marks, '$[0]')
            AND 
                JSON_EXTRACT(User.marks, '$[1]') >= JSON_EXTRACT(CourseRequirements.min_marks, '$[1]')
                -- Add more conditions for additional subjects and marks
            ";

    $result = $conn -> query($sql);
                    
    if ($result === false) {
        die("<p>Query error</p>");
    } //Error handling

    if($result  -> num_rows > 0){

        echo "<table class= \"application\" width = \"100%\">
                <tr style= \"background-color: orange;\">
                    <td>Institution</td>
                    <td>Opening Date</td>
                    <td>Closing Date</td>
                    <td>Course(s)</td>
                    <td width = \"60%\">Description</td>
                </tr>";

        while ($row = $result -> fetch_assoc()) {

            $sql = "INSERT INTO CoursesMatched(user_id, requirement_id)
                    VALUES ('{$_SESSION['user']}', (SELECT requirement_id FROM CourseRequirements WHERE course_name = '{$row['courses']}') )";

            $output = $conn -> query($sql);

            if ($output === false) {
                die("<p>Query error when Inserting into the CoursesMatched table</p>");
            } //Error handling

            echo "<tr>";
            echo "<td>{$row['institution_name']}</td>";
            echo "<td>{$row['applicationOpen_Date']}</td>";
            echo "<td>{$row['applicationClosing_Date']}</td>";
            echo "<td>{$row['courses']}</td>";
            echo "<td>{$row['description']}</td>";
            echo "</tr>";
        }

        echo "</table>";        
            
    } elseif ($result  -> num_rows <= 0){
        echo "<p>Sorry, No Institutions Found :(</p>";
    }
    
    //Closes the Connection
    $conn -> close();
}
?>