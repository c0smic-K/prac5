<?php
    //Security
    require_once('secure.php');

    //DB Credentials
    require_once('config.php');

    //Institution
    $Institution = $_REQUEST['id'];

    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    if ($conn -> connect_error) {
        die("<p>Connection Error</p>");
    }

    $sql = "SELECT like_id 
            FROM ThumbsUp
            WHERE user_id = '{$_SESSION['user']}' AND institution_id = '$Institution'";

    $result = $conn -> query($sql);

    if ($result === false) {
        die("<p>Query Error</p>");
    }

    if ($result -> num_rows == 0) {  //Checks if User already Liked the specific Institution

        $sql = "INSERT INTO ThumbsUp(user_id, institution_id) 
                VALUE('{$_SESSION['user']}', '$Institution')";  //Adds the like to the DB

        $output = $conn -> query($sql);

        if ($output === false) {
            die("<p>Query Error</p>");
        }
        
    }

    //Redirects the user to main page
    header("Location: homeUpdtd.php");
    
    //Close Connection
    $conn -> close();
?>