<?php
    //Security
    require_once('secure.php');
    //Get Credentials
    require_once('config.php');

    //Establish a connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    if ($conn -> connect_error) {
        die("<p>Connection ERROR</p>");
    } // Error Handling

    $sql = "SELECT ratings.user_id, (SELECT username FROM User WHERE user_id = ratings.user_id) AS username, rating, comment 
            FROM ratings 
            ORDER By date
            DESC
            LIMIT 3";

    $result = $conn -> query($sql);

    if ($result === false) {    //Error Handling
        die("<p>Query ERROR</p>");
    } 
    elseif ($result -> num_rows >= 1) {     //Displays the 3 latest comments to the page.
        while ($row = $result -> fetch_assoc()) {
            echo "<br><section class=\"userComments\">";
            echo "<h3>{$row['username']}</h3>";
            echo "<p>{$row['comment']} &nbsp;&nbsp;";

            for ($i=$row['rating']; $i <= 5; $i++) {        //Dispays the Number of stars
                echo "<span class=\"star\">&#9733;</span>";
            }
        
            echo "</p>";
            echo "</section>";
        }
    }

    //CLose connection
    $conn -> close();
?>