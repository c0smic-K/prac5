<?php 
    //Security
    require_once('secure.php');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>College Compass</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="about.css">
        
    </head>
    <body>
        <header style="font-family: 'Courier New', Courier, monospace;">
            <table width="100%">
            <tr>
                <td width="20%" style="text-align: center;">
                <img src="WhatsApp Image 2024-09-11 at 21.31.03_9560cae1.jpg" alt="College Compass logo">
                </td>
                <td style="color: brown; text-align: center;">
                <h1>CollegeCompass</h1>
                <h2>Navigating Your Future, Made Easier.</h2>
                </td>
            </tr>
            </table>
        </header>

        <nav style="font: 1em sans-serif;">
            <ul class="tab">
                <li class="item"><a class="nav" href="homeUpdtd.php">Home</a></li>
                <li class="item"><a class="nav" href="searchUpdtd.php">Search</a></li>
                <li class="item"><a class="nav" href="myInfo.php">myInfo</a></li>
                <li class="item"><a class="nav" href="about.php">About Us</a></li>
                <li><a class="logout" href="logout.php">Logout</a></li>
            </ul>
        </nav>

        <main>
            <div class="about-section">
            <h1>About Us Page</h1>
            <p>
                Welcome to CollegeCompass! We are a dynamic duo in our final year of Computer Science at Rhodes University, where we’re busy transforming caffeine into code and ideas into reality. <br>
                Together, we tackle the challenges of technology with a mix of creativity and precision. Kwakhanya, our efficiency expert, has a talent for solving problems with effortless finesse, while Siyahluma, our full-stack wizard, ensures that our projects shine with innovation and style. <br>
                As we navigate this exciting journey, we’re committed to making a meaningful impact in the digital world. Join us as we explore, innovate, and create a brighter future—one line of code at a time!</p>
            </div>

            <h2 style="text-align:center">Our Team</h2>
            <div class="row">
            <div class="column">
                <div class="card">
                <img src="Kabout.jpg" alt="Kwakhanya Shushu " style = "width : 30%" style = "height : 30%">
                <div class="container">
                    <h2>Kwakhanya Shushu</h2>
                    <p>Meet K. Shushu: the elusive enigma of efficiency wrapped in an aura of laziness. He's the guy who somehow manages to get every task done, but you'll rarely catch him breaking a sweat. Around campus, he's become an urban myth—half-legend, half-mystery—as he quietly slips in and out of classes, hardly interacting with anyone.</p>
                    <p>Email: Hkhanya6@gmail.com</p>
                    <p><a href="mailto:kwakhanya@example.com" class="button">Contact</a></p>
                </div>
                </div>
            </div>

            <div class="column">
                <div class="card">
                <img src="FB_IMG_1686511739726.jpg" alt="Siyahluma Hopu" style = "width : 30%" style = "height : 30%">
                <div class="container">
                    <h2>Siyahluma Hopu</h2>
                    <p>An undergraduate student pursuing a BSc in Computer Science at Rhodes University (Class of 2025). Key Skills include Full-stack development (HTML, CSS, JavaScript, Python, Node.js, React), Problem-solving, Teamwork, and Communication.</p>
                    <p>Email: shopu@gmail.com</p>
                    <p><a href="mailto:siyahluma@example.com" class="button">Contact</a></p>
                </div>
                </div>
            </div>
            </div>
        </main>

        <footer>
            <hr>
            <p>&copy; 2024 College Compass. All rights reserved.</p>
            <p>Author: theGroup &nbsp; 02-Sept-2024</p>
            <p><a href="mailto:thegroup@gmail.com">thegroup@gmail.com</a></p>
        </footer>
    </body>
</html>
