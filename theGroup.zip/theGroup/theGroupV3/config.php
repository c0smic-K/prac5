<?php
    define("SERVERNAME", "cs3-dev.ict.ru.ac.za");
    define("USERNAME", "theGroup");
    define("PASSWORD", "E2alE3J5");
    define("DBNAME", "thegroup");