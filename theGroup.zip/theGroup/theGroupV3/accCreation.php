<?php
    //Security
    require_once('secure.php');
    //gets DB credentials
    require_once('config.php');

    //Establishes a Connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    if ($conn -> connect_error) {
        die("<p>Connection could Not be established</p>");
    }

    $name = $conn -> real_escape_string($_REQUEST['name']);
    $surname = $conn -> real_escape_string($_REQUEST['surname']);
    $mail = $conn -> real_escape_string($_REQUEST['E-mail']);
    $username = $conn -> real_escape_string($_REQUEST['username']);
    $grade = $conn -> real_escape_string($_REQUEST['grade']);
    $password = $conn -> real_escape_string($_REQUEST['confirm_password']);

    $sql = "INSERT INTO User(firstname, surname, username, email, grade, password)
            VALUE ('$name', '$surname', '$username', '$mail', '$grade', sha1('$password'))";

    $result = $conn -> query($sql);

    if ($result === false) {
        die("<p>Query error</p>");
    }

     //Redirects the user to main page
     header("Location: login.php");

    //Close Connection
    $conn -> close();
?>