<?php
    //Security
    require_once('secure.php');

    //gets DB credentials
    require_once('config.php');

    //Establishes a Connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

    if ($conn -> connect_error) {
        die("<p>Connection could Not be established</p>");
    } //Error Handling

    $sql = "SELECT requirement_id, course_name, (SELECT subjects FROM User WHERE user_id = '{$_SESSION['user']}') AS 'userSubjects', (SELECT marks FROM User WHERE user_id = '{$_SESSION['user']}') AS 'userMark', Institution.institution_name, Institution.description, CourseRequirements.min_marks AS 'min_mark', Institution.applicationOpen_Date AS 'Opening Date', Institution.applicationClosing_Date AS 'Closing Date', subject_combinations, Institution.institution_id
            FROM CourseRequirements 
            JOIN Institution
            ON CourseRequirements.institution_id = Institution.institution_id
            ";

    $result = $conn -> query($sql);
                    
    if ($result === false) {
        die("<p>Query error</p>");
    } //Error handling

    $row = $result -> fetch_assoc();

    if(!empty($row['userSubjects'])){

        $userSubjectArray = json_decode($row['userSubjects'], true);
        $userMarksArray = json_decode($row['userMark'], true);

        $subjectArray = json_decode($row['subject_combinations'], true);
        $marksArray = json_decode($row['min_mark'], true);

        $i = 0;

        foreach ($userSubjectArray as $key => $value) {
            foreach ($subjectArray as $key2 => $value2) {
                $subject = (string)$value;
                $subCombi = (string)$value2[$i];

                $userMark = $userMarksArray[$i];
                $mark = $marksArray[$i];

                if ($subject == $subCombi || $i != 0) {
                    $userMark = substr($userMark, 2, 2);
                    $mark = substr($mark, 2, 2);
        
                    if ((int)$userMark >= (int)$mark) {
                        $sql = "INSERT INTO CoursesMatched(user_id, requirement_id)
                                VALUES ('{$_SESSION['user']}', '{$row['requirement_id']}' )";
        
                        $output = $conn -> query($sql);
        
                        if ($output === false) {
                            die("<p>Query error when Inserting into the CoursesMatched table</p>");
                        } //Error handling
        
                        echo "<table class= \"application\" width = \"100%\">
                                <tr style= \"background-color: orange;\">
                                    <td>Institution</td>
                                    <td>Opening Date</td>
                                    <td>Closing Date</td>
                                    <td>Course(s)</td>
                                    <td width = \"60%\">Description</td>
                                </tr>";
                        echo "<tr>";
                        echo "<td>{$row['institution_name']}</td>";
                        echo "<td>{$row['Opening Date']}</td>";
                        echo "<td>{$row['Closing Date']}</td>";
                        echo "<td>{$row['course_name']}</td>";
                        echo "<td>{$row['description']}</td>";
                        echo "</tr>";
                        echo "</table>";  
                    }
                }
            }
        }
    } else {
        echo "<p> Sorry, No Institutions Found :(</p>";
    }

    //Closes the Connection
    $conn -> close();
?>