<?php 
    //Security
    require_once('secure.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="a6aa2143-ee38-4807-95b8-9bc70833fc20.png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="search.css">
    <link rel="js" href="search.js">
    <title>Search</title>
</head>
<body>
    <header style="background-color: lightblue; font-family: 'Courier New', Courier, monospace;">
        
        <table width = "100%">
            <tr>
                <td width = "20%">
                    <img src="WhatsApp Image 2024-09-11 at 21.31.03_9560cae1.jpg" alt="logo" width="100%" height="100%">
                </td>
                <td style="color: brown; text-align: center;">
                    <h1>CollegeCompass</h1>
                    <h2>Navigating Your Future,  Made Easier.</h2>
                </td>
            </tr>
        </table>

    </header>

    <nav style="font: 1em sans-serif;">
        <ul class="tab">
            <li class="item"><a class="nav" href="homeUpdtd.php">Home</a></li>
            <li  class="item"><a class="nav" href="searchUpdtd.php">Search</a></li>
            <li class="item"><a class="nav" href="myInfo.php">myInfo</a></li>
            <li class="item"><a class="nav" href="about.php">About Us</a></li>
            <li><a class="logout" href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <section class="Marks" style="font: 1em sans-serif;">

        <h3 style="padding-left: 3% ;">Enter Marks</h3>

        <form class="form" action="markUpload.php" name="MyMarkform" method="post">
            <fieldset>
                <legend>My Marks:</legend>
            
                <?php 
                    
                    //DB Credentials
                    require_once('config.php');

                    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);

                    if($conn -> connect_error){
                        die("<p>Connection Error</p>");
                    }

                    $sql = "SELECT subjects, marks FROM User WHERE user_id = '{$_SESSION['user']}'";

                    $result = $conn -> query($sql);

                    if($result === false){
                        die("<p>Query Error</p>");
                    } 
                    
                    $row = $result -> fetch_assoc();
                    
                    if(!empty($row['subjects'])){

                        echo "<table width = \"30%\" style= \"float: right;\">
                                <tr style= \"background-color: orange;\">
                                    <td>Subject</td>
                                    <td>Mark</td>
                                </tr>";
                            
                            $subjectArray = json_decode($row['subjects'], true);
                            $marksArray = json_decode($row['marks'], true);
                            $i = 0;
                            foreach ($subjectArray as $key => $value) {
                                $subject = (string)$value;
                                $mark = $marksArray[$i];

                                if($i != 0){
                                    $mark = substr($mark, 2, 2);
                                }
                                echo "<tr>";
                                echo "<td>$subject</td>";
                                echo "<td>$mark</td>";
                                echo "</tr>";
                                $i++; 
                            }
                        echo "</table><br>";

                    } elseif(empty($row['subjects'])) {
                        
                        echo "<table width = \"30%\" style= \"float: right;\">
                                <tr style= \"background-color: orange;\">
                                    <td>Subject</td>
                                    <td>Mark</td>
                                </tr>
                                <tr>
                                    <td>i.e Mathematics</td>
                                    <td>48</td>
                                </tr>
                                <tr>
                                    <td>...</td>
                                    <td>...</td>
                                </tr>
                            </table><br>";
                    }
                
                ?>
             
                <label for="subjects">Choose a Subject:</label>
                <br>

                <select name="subjects" id="subjects" placeholder="subject">
                    <option value="Mathematics">Mathematics</option>
                    <option value="Geography">Geography</option>
                    <option value="Physical Sciences">Physical Sciences</option>
                    <option value="Life Sciences">Life Sciences</option>
                    <option value="IsiXhosa First Additional Language">IsiXhosa First Additional Language</option>
                    <option value="IsiXhosa Home Language">IsiXhosa Home Language</option>
                    <option value="English First Additional Language">English First Additional Language</option>
                    <option value="English Home Language">English Home Language</option>
                    <option value="Life Orientation">Life Orientation</option>
                </select><br>

                <br><input type="text" name="mark" id="mark" placeholder="Mark" size="28"><br>
                <br><input type="submit" value="Submit" id="markBtn" name="markBtn" onclick="markValidation()">
            </fieldset>
        </form>

        <script src="search.js"></script>

        <br><a href="findv2.php"><button class="button" style="vertical-align:middle" name="find"><span>Find</span></button></a>
            
    </section>

    <section class="Results" style="font: 1em sans-serif;">

        <p>A table/list of the Possible choices of institutes and courses</p>
        <?php require('mappedCourses.php'); ?>

    </section>

    <footer style="background-color: lightblue; font-family: 'Courier New', Courier, monospace;">
        <hr>
        <p> &copy; copyright reserved</p> 
        <p>Author: theGroup &nbsp; 02-Sept-2024</p>
        <p><a href="mailto:thegroup@gmail.com">thegroup@gmail.com</a></p><br>
    </footer>
</body>
</html>