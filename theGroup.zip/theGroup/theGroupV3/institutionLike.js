document.addEventListener('DOMContentLoaded', function() {
    const tableRows = document.querySelectorAll('table tr');
  
    tableRows.forEach(row => {
      row.addEventListener('mouseover', () => {
        const hiddenContent = row.querySelector('.hidden-content');
        hiddenContent.style.display = 'block';
      });
  
      row.addEventListener('mouseout', () => {
        const hiddenContent = row.querySelector('.hidden-content');
        hiddenContent.style.display = 'none';
      });
    });
  });