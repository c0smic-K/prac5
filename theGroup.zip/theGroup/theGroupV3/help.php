//my code for the markUpload

<?php
session_start();
require_once('config.php');

$subject = $_POST['subjects'];
$mark = $_POST['mark'];

if (empty($subject) || empty($mark) || !is_numeric($mark) || $mark < 0 || $mark > 100) {
    die("Please enter valid subject and mark (1 - 100).");
}

$conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME);
if ($conn->connect_error) {
    die("<p>Connection could not be established</p>");
}

$sql = "UPDATE User SET marks = JSON_ARRAY_APPEND(marks, '$', ?) WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $mark, $_SESSION['user']);

if ($stmt->execute()) {
    echo "Data uploaded successfully.";
} else {
    die("<p>Query error: " . $stmt->error . "</p>");
}

$stmt->close();
$conn->close();
?>

//my code for the finder
<?php
// Check if the 'find' request is set
if (isset($_REQUEST['find'])) {
    // Security
    require_once('secure.php'); // Include security measures

    // Get DB credentials
    require_once('config.php'); // Include database configuration

    // Establish a Connection
    $conn = new mysqli(SERVERNAME, USERNAME, PASSWORD, DBNAME); // Create a new database connection

    // Check for connection errors
    if ($conn->connect_error) {
        die("<p>Connection could not be established</p>"); // Connection error handling
    }

    // Query to Match Users and Institutions
    $sql = "SELECT Institution.institution_name, Institution.description, Institution.courses, Institution.applicationOpen_Date, Institution.applicationClosing_Date
            FROM User 
            JOIN CoursesMatched ON User.user_id = CoursesMatched.user_id
            JOIN CourseRequirements ON CoursesMatched.requirement_id = CourseRequirements.requirement_id
            JOIN Institution ON CourseRequirements.course_name = Institution.courses
            WHERE
                -- Check if user's subjects and marks meet the requirements
                JSON_CONTAINS(CourseRequirements.subject_combinations, User.subjects)
            AND 
                JSON_EXTRACT(User.marks, '$[0]') >= JSON_EXTRACT(CourseRequirements.min_marks, '$[0]')
            AND 
                JSON_EXTRACT(User.marks, '$[1]') >= JSON_EXTRACT(CourseRequirements.min_marks, '$[1]')";

    // Execute the query
    $result = $conn->query($sql);

    // Check for query execution errors
    if ($result === false) {
        die("<p>Query error</p>"); // Query error handling
    }

    // Check if any institutions were found
    if ($result->num_rows > 0) {
        // Create a table to display results
        echo "<table class=\"application\" width=\"100%\">
                <tr style=\"background-color: orange;\">
                    <td>Institution</td>
                    <td>Opening Date</td>
                    <td>Closing Date</td>
                    <td>Course(s)</td>
                    <td width=\"60%\">Description</td>
                </tr>";

        // Loop through the results and insert into the CoursesMatched table
        while ($row = $result->fetch_assoc()) {
            $sql = "INSERT INTO CoursesMatched(user_id, requirement_id)
                    VALUES ('{$_SESSION['user']}', (SELECT requirement_id FROM CourseRequirements WHERE course_name = '{$row['courses']}'))";
            $output = $conn->query($sql);

            // Check for insert errors
            if ($output === false) {
                die("<p>Query error when inserting into the CoursesMatched table</p>"); // Error handling
            }

            // Display each institution's information
            echo "<tr>";
            echo "<td>{$row['institution_name']}</td>";
            echo "<td>{$row['applicationOpen_Date']}</td>";
            echo "<td>{$row['applicationClosing_Date']}</td>";
            echo "<td>{$row['courses']}</td>";
            echo "<td>{$row['description']}</td>";
            echo "</tr>";
        }
        echo "</table>"; // Close the table
    } else {
        // No institutions found message
        echo "<p>Sorry, no institutions found :(</p>";
    }

    // Close the database connection
    $conn->close();
}
?>
