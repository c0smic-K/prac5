function commentValidation(){
    let comment = document.getElementById("comment").value;

    let msg;

    if (comment.length === 0) {
        msg = "Comment field is empty";
    } else {
        msg = "Comment Added"
    }

    document.getElementById("output").innerHTML = msg;
}